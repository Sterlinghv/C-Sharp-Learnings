﻿class Sample
{
 static void Main()
    {
        //notes on Console classes
        System.Console.WriteLine("Hello"); //created "hello" in the console
        System.Console.Write("Beginning -- ");
        System.Console.Write("of the same line");//both of these are on the same line
        System.Console.ReadKey(); //holds open the console until a key is pressed
        //Console is a class in System, it preforms i/o operations in the console
    }
}