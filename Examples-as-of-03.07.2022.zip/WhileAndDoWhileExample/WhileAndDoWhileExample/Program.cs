﻿class DoWhile
{
    static void Main()
    {
        //while loop 
        // initilization
        // looping up
        int i = 1;
        while(i <= 10)
        {
            System.Console.Write(i+" ");
            i++;
        }
        System.Console.ReadKey();

        //looping down
        i = 10;
        while (i >= 0)
        {
            System.Console.Write(i + " ");
            i--;
        }
        System.Console.ReadKey();

        //do while--
        //same as while but the condition check is at the end, therefor, the loop will be ran ATLEAST once even if the condition is false
        i = 1;
        do
        {
            System.Console.Write(i);
            i++;
        } while (i <= 10);
        System.Console.ReadKey();
    }
}