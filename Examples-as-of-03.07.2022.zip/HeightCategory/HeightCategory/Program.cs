﻿class HeightCategory
{
    static void Main()
    {
        //Write a program to find out "category of height" based on the given height of a person (in inches), using "if".

        int inches = 500;
        double cm = inches * 2.54;
        string category;

        if (cm < 150)
        {
            category = "Dwarf";
        }

        else if (cm >= 150 && cm < 165)
        {
            category = "Average";
        }

        else if (cm >= 165 && cm < 195)
        {
            category = "Tall";
        }

        else 
            category = "Abnormal height";
        
        System.Console.WriteLine(category);
        System.Console.ReadKey();
    }

}