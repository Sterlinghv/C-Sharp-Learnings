﻿public class Customer
{
    public int customerID;
    public string customerName;
}