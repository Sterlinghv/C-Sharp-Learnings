﻿//public class means you can access this class in other assemblies
class Sample
{
   static void main()
    {
        //reference variables
       Customer c1, c2;

        //objects
       c1= new Customer();
       c2= new Customer();
    }
}