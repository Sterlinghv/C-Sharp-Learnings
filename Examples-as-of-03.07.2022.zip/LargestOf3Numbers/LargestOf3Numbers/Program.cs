﻿class LargestOf3Numbers
{
    static void Main()
    {
        //Write a C# program to find out largest number among three numbers, using "if".

        int num1 = 20;
        int num2 = 50;
        int num3 = 100;
        int output;

        if (num1 >= num2 && num1 >= num3)
            output = num1;
        else if (num2 >= num1 && num2 >= num3)
            output = num2;
        else 
            output = num3;

        System.Console.WriteLine(output);
        System.Console.ReadKey();
    }
}