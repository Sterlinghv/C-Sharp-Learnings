﻿class Program
{
static void Main()
    {
        //sbyte
        sbyte a = 10;


        int b;

        //copy value from a to b

        b=a;
    }
}