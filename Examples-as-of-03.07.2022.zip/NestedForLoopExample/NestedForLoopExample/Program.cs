﻿class NestedFLoop
{
    static void Main()
    {
        for(int i = 1; i <= 5; i++)
        {
            for(int j = 1; j <= 5; j++)
            {
                System.Console.Write(i);
                System.Console.Write(" ");
            }
            System.Console.WriteLine();
            
        }
        System.Console.ReadKey();
    }
}