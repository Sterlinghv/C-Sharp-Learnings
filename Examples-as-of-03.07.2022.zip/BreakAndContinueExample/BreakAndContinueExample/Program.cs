﻿class BreakAndContinue
{
    static void Main()
    {
        //using break statement (stops entire loop when the iteration hits 6)
        for(int i = 0; i < 10; i++)
        {
            if(i == 6)
            {
                break;
            }
            System.Console.WriteLine(i);
        }
        System.Console.ReadKey();

        //using continue (it skips the 6'th iteration, but then continues)
        for (int i = 0; i < 10; i++)
        {
            if (i == 6)
            {
                continue;
            }
            System.Console.WriteLine(i);
        }
        System.Console.ReadKey();
    }
}