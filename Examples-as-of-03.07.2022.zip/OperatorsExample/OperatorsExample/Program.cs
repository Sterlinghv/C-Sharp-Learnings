﻿class Sample
{
    static void Main()
    {
        //all operators in c#

        //-------------------------------

        //Arithmitic operators
        decimal a = 10M;
        decimal b = 3M;
        decimal c = a + b; //output 13
        decimal d = a - b; //output 7
        decimal e = a * b; //output 30
        decimal f = a / b; //output 3.3333333
        decimal g = a % b; //output 1
        System.Console.WriteLine(c);
        System.Console.WriteLine(d);
        System.Console.WriteLine(e);
        System.Console.WriteLine(f);
        System.Console.WriteLine(g);
        System.Console.WriteLine(); //blank line
        //Assignment operators

        a += 20M;
        System.Console.WriteLine(a); //output 30
        a -= 20M;
        System.Console.WriteLine(a); //output 10
        a *= 3M;
        System.Console.WriteLine(a); //output 30
        a /= 3M;
        System.Console.WriteLine(a); //output 10
        a %= 3M;
        System.Console.WriteLine(a); //output 1

        //Increment / Decrement operators
        a = 10M;
        System.Console.WriteLine(); //blank line
        System.Console.WriteLine(++a); //output 11
        System.Console.WriteLine(a++); //output 11
        System.Console.WriteLine(a); //output 12
        System.Console.WriteLine(--a); //output 11
        System.Console.WriteLine(--a); //output 11
        System.Console.WriteLine(a); //output 10

        //Comparison operators
        System.Console.WriteLine(); //blank line
        bool b1 = a == 10;
        System.Console.WriteLine(b1); //output true
        bool b2 = a != 10;
        System.Console.WriteLine(b2); //output false
        bool b3 = a < 10;
        System.Console.WriteLine(b3); //ouput false
        bool b4 = a > 10;
        System.Console.WriteLine(b4); //output false
        bool b5 = a <= 10;
        System.Console.WriteLine(b5); //ouput true
        bool b6 = a >= 10;
        System.Console.WriteLine(b6); //output true

        //Logical operators
        System.Console.WriteLine(); //blank line
        bool b7 = a == 10 & b == 10;
        System.Console.WriteLine(b7); //output false
        bool b8 = a == 10 && b == 10;
        System.Console.WriteLine(b8); //output false
        bool b9 = a == 10 | b == 10;
        System.Console.WriteLine(b9); //ouput true
        bool b10 = a == 10 || b == 10;
        System.Console.WriteLine(b10); //output true
        bool b11 =! (a == 10);
        System.Console.WriteLine(b11); //output false
        bool b12 = a == 10 ^ b == 10;
        System.Console.WriteLine(b12); //output true

        //Concatenation operator
        System.Console.WriteLine();
        string name = "Sterling";
        int age = 22;
        string message = "Hey, " + name + ", your age is " + age + ".";
        System.Console.WriteLine(message);

        //Tenary operator
        string title = (age < 13) ? "Child" : (age >= 13 && age <= 19) ? "Teenager" : "Adult";
        System.Console.WriteLine(title);

        //Operator precendence
        double z = 10 + 4 * 30 / 10;
        System.Console.WriteLine(z); //output 22

        System.Console.ReadKey();
    }
}
