﻿class Student
{
    public void DisplaySubjects(params string[]subjects)
    {
        for (int i = 0; i < subjects.Length; i++)
        {
            System.Console.WriteLine(subjects[i]);
        }
    }
}

class Program
{
    static void Main()
    {
        Student s = new Student();

        s.DisplaySubjects("Math", "Science", "English", "Music");

        System.Console.ReadLine();
    }
}
