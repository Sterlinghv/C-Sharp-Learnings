﻿class Switch
{
    static void Main()
    {
        char gradeLetter = 'A';
        string gradeDesc;

        switch (gradeLetter)
        {
            case'O':gradeDesc = "Outstanding";break;
            case'A':gradeDesc = "Great"; break;
            case'B':gradeDesc = "Good"; break;
            case'C':gradeDesc = "Average"; break;
            case'F':gradeDesc = "Failed"; break;
            default:gradeDesc = "None"; break;
        }
        System.Console.WriteLine(gradeDesc);
        System.Console.ReadKey();
    }
}