﻿class Program
{
    static void Main()
    {
        int a = 100;


        float b;

        //int to float
        //in this case it works, because b can hold a
        b=a;

        //another way is
        int c = 100;

        float d;

        d = (float)c;
    }
}