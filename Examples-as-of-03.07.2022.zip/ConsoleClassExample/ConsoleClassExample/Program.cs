﻿class Sample
{
    static void Main()
    {
        //notes on Console classes
        System.Console.WriteLine("Hello"); //created "hello" in the console
        System.Console.Write("Beginning -- ");
        System.Console.Write("of the same line");//both of these are on the same line
        System.Console.ReadKey(); //holds open the console until a key is pressed
        //Console is a class in System, it preforms i/o operations in the console
        System.Console.Clear();


        //------------------------------------------------------------------------------------

        //another example
        //print message line by line and then side by side 
        System.Console.WriteLine("Welcome");
        System.Console.WriteLine("to");
        System.Console.Write("C# Program");

        //wait for pressing key on keyboard
        System.Console.ReadKey();

        //clear the screen
        System.Console.Clear();

        System.Console.WriteLine("Thank you.");
        System.Console.ReadKey();

    }
}