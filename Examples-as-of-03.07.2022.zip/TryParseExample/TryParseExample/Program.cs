﻿class Program
{
    static void Main()
    {
        //read input from keyboard
        string s;
        s = System.Console.ReadLine();

        //tryParse
        bool b = int.TryParse(s, out int n);
        if (b == true)
        {
            System.Console.WriteLine(n);
        }
        else
        {
            System.Console.WriteLine("bad input");
        }

        System.Console.ReadKey();
    }
}