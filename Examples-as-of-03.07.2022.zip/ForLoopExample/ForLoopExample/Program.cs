﻿class ForLoop
{
    static void Main()
    {
        //for loop
        //looping up

        for(int i = 1; i <= 10; i++)
        {
            System.Console.Write(i+" ");
        }
        System.Console.ReadKey();


        //looping down
        for (int i = 10; i>=1 ; i--)
        {
            System.Console.Write(i + " ");
        }
        System.Console.ReadKey();
    }
}
