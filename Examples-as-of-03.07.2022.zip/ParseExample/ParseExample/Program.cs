﻿class Program
{
    static void Main()
    {
        //parse must only be used if you are 100% sure all of the characters in a string, are numerical. 
        //tryParse can be used if you are not sure.

        //string
        string a = "100";

        //int
        int b;

        //string to int
        b = int.Parse(a);

    }
}
