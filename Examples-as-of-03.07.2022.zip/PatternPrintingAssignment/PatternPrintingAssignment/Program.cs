﻿class program
{
    static void Main()
    {
        //Write a C# program to print the following output by using 'for' loop, 'break' and 'continue' statements
        for (int i = 1; i <= 3; i++)
        {
            for (int j = 1; j <= 10; j++)
            {
                if (j == 5)
                {
                    continue;
                }
                System.Console.Write(j);
                System.Console.Write(" ");
            }
            System.Console.WriteLine(" ");
        }

        for(int i = 1; i <= 4;i++)
        {
            for(int j = 10; j >= 1; j--)
            {
                if(i == 3 && j == 2)
                {
                    break;
                }
                System.Console.Write(j);
                System.Console.Write(" ");
            }
            System.Console.WriteLine(" ");
        }

        for(int i = 1; i<=10; i++)
        {
            if(i == 8)
            {
                continue;
            }
            System.Console.Write(i);
            System.Console.Write(" ");
        }

        System.Console.ReadKey();
    }
}