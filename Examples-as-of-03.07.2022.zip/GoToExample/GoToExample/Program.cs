﻿class program
{
    static void Main()
    {
        //forward goto statement
        System.Console.WriteLine("USA");
        System.Console.WriteLine("UK");
        System.Console.WriteLine("France");
        goto myLabel;

        System.Console.WriteLine("Germany");
        System.Console.WriteLine("Russia");
        System.Console.WriteLine("India");
        myLabel:

        System.Console.WriteLine("Spain");
        System.Console.WriteLine("Vietnam");

        System.Console.ReadKey();


        //backward facing
        int i = 1;
        System.Console.WriteLine("USA");
        System.Console.WriteLine("UK");
        System.Console.WriteLine("France");
        myLabel2:

        System.Console.WriteLine("Germany");
        System.Console.WriteLine("Russia");
        System.Console.WriteLine("India");
        i++;
            if(i<5)
        {
            goto myLabel2;
        }//fixes infinite loop of backward facing
        System.Console.WriteLine("Spain");
        System.Console.WriteLine("Vietnam");

        System.Console.ReadKey();


    }
}