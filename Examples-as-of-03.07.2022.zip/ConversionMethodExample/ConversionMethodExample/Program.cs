﻿class Program
{
    static void Main()
    {
        //int
        int a = 100;

        //string
        string b;

        //convert int to string
        b = System.Convert.ToString(a);
    }
}