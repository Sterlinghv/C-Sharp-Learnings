﻿class HeightConversion
{
    static void Main()
    {
        int heightF = 6;
        int heightI = 2;
        System.Console.WriteLine("Your height is " + heightF + " Feet" + ", " + heightI + " Inches");

        double heightFCM = (heightF * 12) * 2.54;
        double heightICM = heightI * 2.54;
        double total = heightFCM + heightICM;
        System.Console.WriteLine("Your height in CM is " + total);
        System.Console.ReadKey();
    }
}