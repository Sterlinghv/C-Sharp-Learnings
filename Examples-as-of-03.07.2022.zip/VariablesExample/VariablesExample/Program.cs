﻿class Sample
{
    static void Main()
    {
        //declare the variables
        string studentName = "Sterling";
        int age = 22;

        //print values
        System.Console.WriteLine("Hello, "+studentName);
        System.Console.WriteLine("Your current age is: " + age + " years old.");

        //hold console
        System.Console.ReadKey();

        //----------------------------------
        //more notes

        //type aka data type specifies what type of value to be stored in memory
        //there is two types in c#, primitive and none primitive
        //string is actually a non primitive type, classes too, interfaces, structures, and enumerators for example
        //what defines primitive and nonprimitive is how many values are stored. A string for example --- 
        //stores multiple values of char, so its a non primitive, a int however is simply one int, so its primitive. 
    }
}