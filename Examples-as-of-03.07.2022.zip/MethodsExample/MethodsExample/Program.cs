﻿class Sample
{
    static void Main()
    {
        //important note about fields: Fields are variables that are declared in the class; but
        // stored in objects. Static fields are stored outside the objects. 
        // 3 modifiers static, const, readonly

        //local constant
        const string developerName = "Sterling";
        //create reference variables
        Product product1, product2, product3;

        //create objects
        product1 = new Product();
        Product.SetTotalNoOfProducts(Product.GetTotalNoOfProducts()+1);    //1
        product2 = new Product();
        Product.SetTotalNoOfProducts(Product.GetTotalNoOfProducts() + 1);  //2
        product3 = new Product();
        Product.SetTotalNoOfProducts(Product.GetTotalNoOfProducts() + 1);  //3

        //initialize fields
        product1.SetProductID(1001);
        product1.SetProductName("Mobile");
        product1.SetCost(20000);
        product1.SetQuantityInStock(1200);
        product2.SetProductID(1003);
        product2.SetProductName("Laptop");
        product2.SetCost(45000);
        product2.SetQuantityInStock(3400);
        product3.SetProductID(1008);
        product3.SetProductName("Speakers");
        product3.SetCost(36000);
        product3.SetQuantityInStock(800);

        //call methods 
        product1.CalculateTax(percentage:9.2);
        double p = 7.4;
        product2.CalculateTax(p);
        product3.CalculateTax(10000, 3.4);

        //get values from fields
        System.Console.WriteLine("Developers name is: " + developerName);
        System.Console.WriteLine("\nProduct 1:");
        System.Console.WriteLine("Product ID is: " + product1.GetProductID());
        System.Console.WriteLine("Product name is: " + product1.GetProductName());
        System.Console.WriteLine("Product cost is: " + product1.GetCost());
        System.Console.WriteLine("Quantity in stock is: " + product1.GetQuantityInStock());
        System.Console.WriteLine("Date of purchase: " + product1.GetDateOfPurchase());
        System.Console.WriteLine("Tax: " + product1.GetTax());

        System.Console.WriteLine("\nProduct 2:");
        System.Console.WriteLine("Product ID is: " + product2.GetProductID());
        System.Console.WriteLine("Product name is: " + product2.GetProductName());
        System.Console.WriteLine("Product cost is: " + product2.GetCost());
        System.Console.WriteLine("Quantity in stock is: " + product2.GetQuantityInStock());
        System.Console.WriteLine("Date of purchase: " + product2.GetDateOfPurchase());
        System.Console.WriteLine("Tax: " + product2.GetTax());

        System.Console.WriteLine("\nProduct 3:");
        System.Console.WriteLine("Product ID is: " + product3.GetProductID());
        System.Console.WriteLine("Product name is: " + product3.GetProductName());
        System.Console.WriteLine("Product cost is: " + product3.GetCost());
        System.Console.WriteLine("Quantity in stock is: " + product3.GetQuantityInStock());
        System.Console.WriteLine("Date of purchase: " + product3.GetDateOfPurchase());
        System.Console.WriteLine("Tax: " + product3.GetTax());

        //total quantity
        int totalQuantity = Product.GetTotalQuantity(product1, product2, product3);

        //display totals
        System.Console.WriteLine("\nTotal quantity is: " + totalQuantity);
        System.Console.WriteLine("Total number of products is: " + Product.GetTotalNoOfProducts());
        System.Console.WriteLine("Category of products: " + Product.CategoryName);
        System.Console.ReadKey();



    }
}
