﻿public class Product
{
    //fields
    private int productID;
    private string productName;
    private double cost;
    private double tax;
    private int quantityInStock;
    public static int totalNoProducts;
    public const string CategoryName = "Electronics";
    private readonly string dateOfPurchase;

    // constructor
    public Product()
    {
        dateOfPurchase = System.DateTime.Now.ToShortTimeString();
    }

    //set method for productID
    public void SetProductID(int value)
    {
        productID = value;
    }

    //get method for productID
    public int GetProductID ()
    {
        return productID;
    }

    //set method for productName
    public void SetProductName(string value)
    {
        productName = value;
    }

    //get method for productName
    public string GetProductName()
    {
        return productName;
    }

    //set method for cost
    public void SetCost(double value)
    {
        cost = value;
    }

    //get method for cost
    public double GetCost ()
    {
        return cost;
    }

    //set method for tax
    public void SetTax(double value)
    {
        tax = value;
    }

    //get method for tax
    public double GetTax()
    {
        return tax;
    }

    //methods for calculating tax
    public void CalculateTax(double percentage)
    {
        //create local variable
        double t;

        //calculate tax
        if (cost <= 20000)
        {
            t = cost * 10 / 100;
        }
        else
        {
            t = cost * percentage / 100;
        }

        tax = t;
    }

    public void CalculateTax(double cost, double percentage = 4.5)
    {
        //create local variable
        double t;

        //calculate tax
        if (cost <= 50000)
        {
            t = cost * 5 / 100;
        }
        else
        {
            t = cost * percentage / 100;
        }

        tax = t;
    }

    //set method for quantityInStock
    public void SetQuantityInStock(int value)
    {
        quantityInStock = value;
    }

    //get method for quantityInStock
    public int GetQuantityInStock()
    {
        return quantityInStock;
    }

    //get method for dateOfPurchase
    public string GetDateOfPurchase()
    {
        return dateOfPurchase;
    }

    //static method: set  method for TotalNumberOfProducts
    public static void SetTotalNoOfProducts(int value)
    {
        totalNoProducts = value;
    }

    public static int GetTotalNoOfProducts()
    {
        return totalNoProducts;
    }

    //static method calculate total quantity
    public static int GetTotalQuantity(Product product1, Product product2, Product product3)
    {
        int total;
        total = product1.GetQuantityInStock() + product2.GetQuantityInStock() + product3.GetQuantityInStock();
        return total;
    }
}
