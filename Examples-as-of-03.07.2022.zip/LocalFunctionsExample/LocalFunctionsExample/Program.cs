﻿class Student
{
    public void DisplayMarks(int marks1, int marks2, int marks3)
    {
        double avgMarks = getAverageMarks(marks1, marks2, marks3);
        System.Console.WriteLine("Marks 1: " + marks1);
        System.Console.WriteLine("Marks 2: " + marks2);
        System.Console.WriteLine("Marks 3: " + marks3);
        System.Console.WriteLine("Average marks: " + avgMarks);

        //create local function

       static double getAverageMarks(int m1, int m2, int m3)
        {
            double average;
            average =(double)(m1 + m2 + m3)/3;
            return average;
        }
    }
}

class Program
{
    static void Main()
    {
        Student s = new Student();

        s.DisplayMarks(80, 45, 71);

        System.Console.ReadKey();
    }
}